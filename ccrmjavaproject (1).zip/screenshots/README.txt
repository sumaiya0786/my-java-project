These are placeholder screenshots generated automatically. Replace with real screenshots if required.
Files:
- java-version.png
- eclipse-setup.png
- program-running.png
- backup-folder.png
