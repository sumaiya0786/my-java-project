# USAGE

1. Import the project into Eclipse:
   - File → Import → Existing Projects into Workspace → Select unzipped folder.

2. Run:
   - Run `edu.ccrm.cli.MainMenu` as Java Application.

3. Sample import:
   - Use the CLI 'Import Students' or run ImportExportService on `test-data/students.csv`.

4. Test data files:
   - `test-data/students.csv`
   - `test-data/courses.csv`

