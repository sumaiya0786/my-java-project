package edu.ccrm.service.impl;

import edu.ccrm.domain.Student;
import edu.ccrm.service.StudentService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Simple in-memory student service for demo / skeleton purposes.
 */
public class InMemoryStudentService implements StudentService {
    private final List<Student> students = new ArrayList<>();

    public InMemoryStudentService() {
        // seed sample students
        students.add(new Student("1", "REG2025/001", "Aria Singh", "aria@example.com", LocalDate.now()));
        students.add(new Student("2", "REG2025/002", "Dev Patel", "dev@example.com", LocalDate.now()));
    }

    @Override
    public Student addStudent(Student s) {
        students.add(s);
        return s;
    }

    @Override
    public List<Student> listStudents() {
        return new ArrayList<>(students);
    }
}
