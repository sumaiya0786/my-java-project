package edu.ccrm.domain;

/**
 * Example Builder for Course (demonstrates Builder pattern).
 */
public class CourseBuilder {
    private String code;
    private String title;
    private int credits;
    private String instructor;
    private Semester semester;
    private String department;

    public CourseBuilder withCode(String code) { this.code = code; return this; }
    public CourseBuilder withTitle(String title) { this.title = title; return this; }
    public CourseBuilder withCredits(int credits) { this.credits = credits; return this; }
    public CourseBuilder withInstructor(String instructor) { this.instructor = instructor; return this; }
    public CourseBuilder withSemester(Semester sem) { this.semester = sem; return this; }
    public CourseBuilder withDepartment(String dept) { this.department = dept; return this; }

    public Course build() {
        return new Course(code, title, credits, instructor, semester, department);
    }
}
