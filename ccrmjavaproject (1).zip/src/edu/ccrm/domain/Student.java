package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Student extends Person {
    private String regNo;
    private Status status = Status.ACTIVE;
    private final LocalDate createdAt;
    private final List<String> enrolledCourseCodes = new ArrayList<>();

    public enum Status { ACTIVE, INACTIVE }

    public Student(String id, String regNo, String fullName, String email, LocalDate createdAt) {
        super(id, fullName, email);
        this.regNo = regNo;
        this.createdAt = createdAt;
    }

    public String getRegNo() { return regNo; }
    public Status getStatus() { return status; }
    public void deactivate() { this.status = Status.INACTIVE; }

    public List<String> getEnrolledCourseCodes() { return enrolledCourseCodes; }

    @Override
    public String getProfile() {
        return String.format("Student[id=%s, regNo=%s, name=%s, email=%s]", id, regNo, fullName, email);
    }

    @Override
    public String toString() { return getProfile(); }
}
