package edu.ccrm.config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Singleton configuration holder.
 */
public class AppConfig {
    private static AppConfig instance;
    private final Path dataFolder;

    private AppConfig() {
        // default data folder (can be loaded from properties)
        this.dataFolder = Paths.get("data").toAbsolutePath();
    }

    public static synchronized AppConfig getInstance() {
        if (instance == null) instance = new AppConfig();
        return instance;
    }

    public Path getDataFolder() {
        return dataFolder;
    }
}
