package edu.ccrm.io;

import java.nio.file.Path;

public class ImportExportService {
    // TODO: Implement CSV import/export using NIO.2 and Streams.
    public void importStudents(Path csvFile) {
        System.out.println("Import students from: " + csvFile);
    }
}
