package edu.ccrm.io;

import java.nio.file.Path;

public class BackupService {
    // TODO: implement backup using Files.walk, copy, move, timestamped folder
    public Path backupExports(Path exportsFolder) {
        System.out.println("Backup exports in folder: " + exportsFolder);
        return exportsFolder;
    }
}
