package edu.ccrm.cli;

import edu.ccrm.config.AppConfig;
import edu.ccrm.service.StudentService;
import edu.ccrm.service.impl.InMemoryStudentService;

import java.util.Scanner;

public class MainMenu {
    public static void main(String[] args) {
        // Load AppConfig (Singleton)
        AppConfig config = AppConfig.getInstance();
        System.out.println("CCRM - Campus Course & Records Manager");
        System.out.println("Data folder: " + config.getDataFolder());

        StudentService studentService = new InMemoryStudentService();

        Scanner sc = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("\nMain Menu:\n1) Manage Students\n2) Manage Courses\n3) Enrollment & Grades\n4) Import/Export\n5) Backup\n6) Reports\n0) Exit");
            System.out.print("Choose: ");
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1":
                    System.out.println("Student management - simple demo");
                    studentService.listStudents().forEach(System.out::println);
                    break;
                case "0":
                    running = false;
                    break;
                default:
                    System.out.println("Option not implemented in skeleton.");
            }
        }
        sc.close();
        System.out.println("Goodbye.");
    }
}
